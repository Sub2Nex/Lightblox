#pragma once

#define RFU_VERSION "4.4.2"
#define RFU_GITHUB_REPO "axstin/rbxfpsunlocker"

bool CheckForUpdates();
void SetFPSCapExternal(double value);
